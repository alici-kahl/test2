// src/app/api/route/plan/route.ts
import { NextRequest, NextResponse } from "next/server";

type Coords = [number, number];
export const dynamic = "force-dynamic";

/** Polyline6-Decoder */
function decodePolyline6(str: string): Coords[] {
  let index = 0, lat = 0, lon = 0;
  const coordinates: Coords[] = [];
  if (!str || typeof str !== "string") return coordinates;
  const shiftAndMask = () => {
    let result = 0, shift = 0, b: number;
    do {
      b = str.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    return (result & 1) ? ~(result >> 1) : (result >> 1);
  };
  while (index < str.length) {
    lat += shiftAndMask();
    lon += shiftAndMask();
    coordinates.push([lon / 1e6, lat / 1e6]);
  }
  return coordinates;
}

function bboxOf(coords: Coords[]) {
  let minLon = Infinity, minLat = Infinity, maxLon = -Infinity, maxLat = -Infinity;
  for (const [x, y] of coords) {
    if (x < minLon) minLon = x;
    if (y < minLat) minLat = y;
    if (x > maxLon) maxLon = x;
    if (y > maxLat) maxLat = y;
  }
  return [minLon, minLat, maxLon, maxLat] as [number, number, number, number];
}

/** Alle Koordinaten einer Valhalla-Trip-Route holen (trip.shape ODER concat(leg.shape)) */
function tripToCoords(trip: any): Coords[] {
  if (!trip) return [];
  if (typeof trip.shape === "string" && trip.shape.length) {
    return decodePolyline6(trip.shape);
  }
  const legs: any[] = Array.isArray(trip.legs) ? trip.legs : [];
  let out: Coords[] = [];
  for (const leg of legs) {
    const part = decodePolyline6(leg?.shape || "");
    if (part.length === 0) continue;
    if (out.length && part.length) {
      // erstes Punkt der Teilroute = letztes der vorherigen? Dann doppelt vermeiden
      const [plon, plat] = part[0];
      const [olon, olat] = out[out.length - 1];
      if (plon === olon && plat === olat) {
        out = out.concat(part.slice(1));
        continue;
      }
    }
    out = out.concat(part);
  }
  return out;
}

/**
 * Request-Format:
 * { start:[lon,lat], end:[lon,lat],
 *   vehicle:{width_m,height_m,weight_t,axleload_t},
 *   obstacle?:{type:"Point",coordinates:[lon,lat]},
 *   buffer_m?:number, alternatives?:number }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const start: Coords = body.start;
    const end: Coords = body.end;
    if (!Array.isArray(start) || !Array.isArray(end) || start.length !== 2 || end.length !== 2) {
      return NextResponse.json({ error: "start/end must be [lon,lat]" }, { status: 400 });
    }

    const width_m  = Number(body?.vehicle?.width_m ?? 3);
    const height_m = Number(body?.vehicle?.height_m ?? 4);
    const weight_t = Number(body?.vehicle?.weight_t ?? 40);
    const axle_t   = Number(body?.vehicle?.axleload_t ?? 10);
    const alternatives = Math.max(
      0,
      Math.min(3, Number.isFinite(body.alternatives) ? Number(body.alternatives) : 0)
    );

    const avoid: Coords[] = [];
    if (body.obstacle?.type === "Point" && Array.isArray(body.obstacle.coordinates)) {
      const [lon, lat] = body.obstacle.coordinates as Coords;
      if (Number.isFinite(lon) && Number.isFinite(lat)) avoid.push([lon, lat]);
    }

    const valReq: any = {
      locations: [{ lon: start[0], lat: start[1] }, { lon: end[0], lat: end[1] }],
      costing: "truck",
      costing_options: {
        truck: { height: height_m, width: width_m, weight: weight_t, axle_load: axle_t }
      },
      directions_options: { language: "de-DE" },
      units: "kilometers",
      shape_format: "polyline6",
      encoded_polyline: true
    };
    if (alternatives > 0) valReq.alternates = alternatives;
    if (avoid.length) valReq.avoid_locations = avoid.map(([lon, lat]) => ({ lon, lat }));

    const resp = await fetch("http://localhost:8002/route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(valReq),
    });

    const json = await resp.json();

    if (!resp.ok || !json?.trip) {
      return NextResponse.json(
        { error: json?.error || json || "valhalla error", status: resp.status },
        { status: resp.status || 500 }
      );
    }

    const asFeature = (trip: any) => {
      const coords = tripToCoords(trip);
      if (coords.length === 0) {
        throw new Error("Valhalla lieferte keine Shape-Daten (trip/legs).");
      }
      const steps = (trip.legs?.[0]?.maneuvers || []).map((m: any) => ({
        instruction: m.instruction,
        distance: (m.length || 0) * 1000,
        duration: m.time || 0,
        street_names: m.street_names || undefined,
        type: m.type
      }));
      const summary = trip.summary || {};
      const props = {
        summary: { distance: (summary.length || 0) * 1000, duration: summary.time || 0 },
        segments: [{ steps }],
      };
      const bb = bboxOf(coords);
      return {
        type: "Feature",
        geometry: { type: "LineString", coordinates: coords },
        properties: props,
        bbox: bb,
      };
    };

    const features: any[] = [asFeature(json.trip)];

    const altKeys = ["alternates", "alternate_paths", "alternate_routes"];
    const altArr =
      altKeys.map((k) => (Array.isArray(json?.[k]) ? json[k] : null)).find((a) => Array.isArray(a)) || [];

    for (const alt of altArr as any[]) {
      const trip = alt?.trip || alt; // manche Varianten legen trip direkt ab
      if (trip) features.push(asFeature(trip));
    }

    return NextResponse.json({
      type: "FeatureCollection",
      features,
      bbox: features[0]?.bbox,
    });
  } catch (err: any) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
