// src/app/api/route/valhalla/route.ts
import { NextRequest, NextResponse } from "next/server";

type Coords = [number, number];
export const dynamic = "force-dynamic";

function decodePolyline6(str: string): [number, number][] {
  let index = 0, lat = 0, lon = 0;
  const out: [number, number][] = [];
  while (index < str.length) {
    let b, shift = 0, result = 0;
    do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlat = (result & 1) ? ~(result >> 1) : (result >> 1);
    lat += dlat;
    shift = 0; result = 0;
    do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlon = (result & 1) ? ~(result >> 1) : (result >> 1);
    lon += dlon;
    out.push([lon / 1e6, lat / 1e6]); // [lon, lat]
  }
  return out;
}

function bboxFromCoords(coords: [number, number][]) {
  let minLon = Infinity, minLat = Infinity, maxLon = -Infinity, maxLat = -Infinity;
  for (const [lon, lat] of coords) {
    if (lon < minLon) minLon = lon;
    if (lat < minLat) minLat = lat;
    if (lon > maxLon) maxLon = lon;
    if (lat > maxLat) maxLat = lat;
  }
  return [minLon, minLat, maxLon, maxLat] as [number, number, number, number];
}

async function streetsForShape(valhallaUrl: string, encoded: string): Promise<string[]> {
  try {
    const r = await fetch(`${valhallaUrl}/trace_attributes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        encoded_polyline: encoded,
        filters: { attributes: ["edge.names", "edge.id"] },
      }),
    });
    if (!r.ok) return [];
    const j = await r.json();
    const list: string[] = [];
    if (Array.isArray(j?.edges)) {
      for (const e of j.edges) {
        if (Array.isArray(e?.names)) {
          for (const n of e.names) if (n?.text) list.push(String(n.text));
        }
      }
    }
    return list;
  } catch {
    return [];
  }
}

/**
 * Body:
 * {
 *   start:[lon,lat],
 *   end:[lon,lat],
 *   vehicle:{ width_m, height_m, weight_t, axleload_t },
 *   directions_language?: string
 * }
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const start: Coords = body.start;
    const end: Coords = body.end;
    if (!Array.isArray(start) || !Array.isArray(end) || start.length !== 2 || end.length !== 2) {
      return NextResponse.json({ error: "start/end must be [lon,lat]" }, { status: 400 });
    }

    const width = Number(body?.vehicle?.width_m ?? 3);
    const height = Number(body?.vehicle?.height_m ?? 4);
    const weight = Number(body?.vehicle?.weight_t ?? 40);
    const axle = Number(body?.vehicle?.axleload_t ?? 10);
    const lang = String(body?.directions_language || "de-DE");
    const VALHALLA_URL = process.env.VALHALLA_URL || "http://localhost:8002";

    // Immer mindestens 2 Alternativen anfragen
    const requestedAlternates = 2;

    const routePayload = {
      locations: [{ lon: start[0], lat: start[1] }, { lon: end[0], lat: end[1] }],
      costing: "truck",
      costing_options: { truck: { height, width, weight, axle_load: axle } },
      directions_options: { language: lang, units: "kilometers" },
      alternates: requestedAlternates,
    };

    const r = await fetch(`${VALHALLA_URL}/route`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(routePayload),
    });
    const j = await r.json();
    if (!r.ok || !j?.trip?.legs?.[0]) {
      return NextResponse.json({ error: j?.error || j, status: r.status }, { status: 500 });
    }

    // Helper, um aus einer Valhalla-Route (trip oder leg) ein Feature zu bauen
    const toFeature = async (tripLike: any, idx: number) => {
      const leg = tripLike?.legs?.[0] ?? tripLike?.trip?.legs?.[0] ?? tripLike;
      const shape: string = leg.shape;
      const coords = decodePolyline6(shape);
      const bbox = bboxFromCoords(coords);
      const streets_sequence = await streetsForShape(VALHALLA_URL, shape);
      const maneuvers = (leg.maneuvers || []).map((m: any) => ({
        instruction: m.instruction,
        distance_km: m.length,
        duration_s: m.time,
        street_names: m.street_names || m.begin_street_names || [],
      }));
      const summary = {
        distance_km: tripLike?.summary?.length ?? leg?.summary?.length ?? 0,
        duration_s: tripLike?.summary?.time ?? leg?.summary?.time ?? 0,
      };
      return {
        type: "Feature" as const,
        geometry: { type: "LineString" as const, coordinates: coords },
        properties: { idx, maneuvers, streets_sequence, summary, bbox },
      };
    };

    const features: any[] = [];
    // Hauptroute
    features.push(await toFeature(j.trip, 0));
    // Alternativen – Valhalla liefert je nach Version unterschiedliche Struktur:
    const altsArr = Array.isArray(j.alternates) ? j.alternates : [];
    for (let i = 0; i < altsArr.length; i++) {
      features.push(await toFeature(altsArr[i]?.trip ?? altsArr[i], i + 1));
    }

    // Falls weniger geliefert wurden, Features trotzdem liefern; Renderer zeigt, was da ist
    const allBboxes = features.map(f => f.properties.bbox);
    const union = allBboxes.reduce<[number, number, number, number]>(
      (acc, b) => [Math.min(acc[0], b[0]), Math.min(acc[1], b[1]), Math.Max?.(0 as any,0) || Math.max(acc[2], b[2]), Math.max(acc[3], b[3])],
      features[0].properties.bbox
    );

    const geojson = { type: "FeatureCollection", features };
    return NextResponse.json({ geojson, bbox: union });
  } catch (err: any) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
