"use client";

import { useEffect, useRef, useState } from "react";
import maplibregl, { Map, MapMouseEvent } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import "./globals.css";

type Coords = [number, number];

function parseLonLat(input: string): Coords | null {
  const parts = input.split(",").map((s) => s.trim());
  if (parts.length !== 2) return null;
  const lon = Number(parts[0]);
  const lat = Number(parts[1]);
  if (!Number.isFinite(lon) || !Number.isFinite(lat)) return null;
  return [lon, lat];
}

async function geocode(addr: string): Promise<Coords | null> {
  const u = new URL("https://nominatim.openstreetmap.org/search");
  u.searchParams.set("format", "jsonv2");
  u.searchParams.set("limit", "1");
  u.searchParams.set("q", addr);
  u.searchParams.set("countrycodes", "de");
  const r = await fetch(u.toString(), {
    headers: { "User-Agent": "route-mvp/0.1 (demo)", "Accept-Language": "de" },
  });
  const j = await r.json();
  if (Array.isArray(j) && j[0]) {
    const lon = Number(j[0].lon);
    const lat = Number(j[0].lat);
    if (Number.isFinite(lon) && Number.isFinite(lat)) return [lon, lat];
  }
  return null;
}

const sToMin = (s: number) => Math.round(s / 60);

type Suggestion = { label: string; coord: Coords; raw: any };

function formatSuggestion(row: any): string | null {
  const a = row?.address || {};
  const road =
    a.road ||
    a.pedestrian ||
    a.footway ||
    a.path ||
    a.cycleway ||
    a.residential ||
    a.neighbourhood;
  const housenr = a.house_number || "";
  const postcode = a.postcode || "";
  const city =
    a.city || a.town || a.village || a.municipality || a.suburb || a.hamlet || a.county || "";

  if (!road && !postcode && !city) return null;

  const streetPart = [road, housenr].filter(Boolean).join(" ").trim();
  const placePart = [postcode, city].filter(Boolean).join(", ").trim();

  return [streetPart, placePart].filter(Boolean).join(", ");
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function AutocompleteInput(props: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  onSelect: (s: Suggestion) => void;
  getMapInfo: () => {
    center?: { lat: number; lon: number };
    bounds?: { left: number; top: number; right: number; bottom: number };
  };
}) {
  const { value, onChange, placeholder, onSelect, getMapInfo } = props;
  const [open, setOpen] = useState(false);
  const [focused, setFocused] = useState(false);
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<Suggestion[]>([]);
  const [hi, setHi] = useState(0);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const debounceRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const reqIdRef = useRef(0);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) {
        setOpen(false);
        setFocused(false);
        abortRef.current?.abort();
      }
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  useEffect(() => {
    if (!focused) {
      setOpen(false);
      setLoading(false);
      abortRef.current?.abort();
      return;
    }
    if (value.trim().length < 3) {
      setItems([]);
      setOpen(false);
      return;
    }

    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(async () => {
      abortRef.current?.abort(); // laufende Suche abbrechen
      const aborter = new AbortController();
      abortRef.current = aborter;
      const myReqId = ++reqIdRef.current;

      try {
        setLoading(true);
        const info = getMapInfo();

        const u = new URL("https://nominatim.openstreetmap.org/search");
        u.searchParams.set("format", "jsonv2");
        u.searchParams.set("addressdetails", "1");
        u.searchParams.set("limit", "10");
        u.searchParams.set("q", value.trim());
        u.searchParams.set("countrycodes", "de"); // strikt Deutschland

        if (info.center) {
          u.searchParams.set("lat", String(info.center.lat));
          u.searchParams.set("lon", String(info.center.lon));
        }
        if (info.bounds) {
          const { left, top, right, bottom } = info.bounds;
          u.searchParams.set("viewbox", `${left},${top},${right},${bottom}`);
        }

        const r = await fetch(u.toString(), {
          headers: { "User-Agent": "route-mvp/0.1 (demo)", "Accept-Language": "de" },
          signal: aborter.signal,
        });
        const j = await r.json();

        if (reqIdRef.current !== myReqId) return; // veraltete Antwort ignorieren

        let list: Suggestion[] = Array.isArray(j)
          ? j
              .map((row: any) => {
                const label = formatSuggestion(row);
                if (!label) return null;
                return {
                  label,
                  coord: [Number(row.lon), Number(row.lat)] as Coords,
                  raw: row,
                };
              })
              .filter(Boolean) as Suggestion[]
          : [];

        const ctr = info.center;
        const b = info.bounds;
        const inBox = (s: Suggestion) =>
          b
            ? s.coord[0] >= b.left &&
              s.coord[0] <= b.right &&
              s.coord[1] >= b.bottom &&
              s.coord[1] <= b.top
            : false;

        // stabile, deterministische Sortierung
        list = list
          .map((s) => {
            const dist =
              ctr ? haversine(ctr.lat, ctr.lon, s.coord[1], s.coord[0]) : Number.POSITIVE_INFINITY;
            const rank = typeof s.raw?.place_rank === "number" ? s.raw.place_rank : 0;
            const imp = typeof s.raw?.importance === "number" ? s.raw.importance : 0;
            return {
              s,
              key: [
                inBox(s) ? 0 : 1, // 0 = im Kartenausschnitt
                Math.round(dist), // Entfernung (m)
                -rank, // höhere place_rank bevorzugen
                -imp, // höhere importance bevorzugen
                s.label.toLowerCase(), // stabiler Fallback
              ] as (number | string)[],
            };
          })
          .sort((a, b2) => {
            for (let i = 0; i < a.key.length; i++) {
              const av = a.key[i];
              const bv = b2.key[i];
              if (av === bv) continue;
              if (typeof av === "number" && typeof bv === "number") return av - bv;
              return String(av).localeCompare(String(bv), "de");
            }
            return 0;
          })
          .map((x) => x.s);

        setItems(list);
        setHi(0);
        setOpen(focused && list.length > 0);
      } catch (err) {
        if ((err as any)?.name !== "AbortError") {
          setItems([]);
          setOpen(false);
        }
      } finally {
        if (reqIdRef.current === myReqId) setLoading(false);
      }
    }, 220) as unknown as number;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, focused, getMapInfo]);

  const selectIdx = (idx: number) => {
    const s = items[idx];
    if (!s) return;
    onSelect(s);
    setOpen(false);
    setFocused(false);
    abortRef.current?.abort();
  };

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <input
        className="inp"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => {
          setFocused(true);
        }}
        onKeyDown={(e) => {
          if (!open) return;
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setHi((p) => Math.min(items.length - 1, p + 1));
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHi((p) => Math.max(0, p - 1));
          } else if (e.key === "Enter") {
            e.preventDefault();
            selectIdx(hi);
          } else if (e.key === "Escape") {
            setOpen(false);
            setFocused(false);
            abortRef.current?.abort();
          }
        }}
      />
      {open && (
        <div
          style={{
            position: "absolute",
            zIndex: 20,
            top: "100%",
            left: 0,
            right: 0,
            background: "#fff",
            border: "1px solid #ddd",
            borderRadius: 8,
            marginTop: 4,
            maxHeight: 280,
            overflow: "auto",
            boxShadow: "0 8px 16px rgba(15,23,42,.08), 0 1px 2px rgba(15,23,42,.08)",
          }}
        >
          {loading && <div style={{ padding: 10, fontSize: 13, color: "#666" }}>Suche…</div>}
          {!loading &&
            items.map((it, i) => (
              <div
                key={i}
                onMouseEnter={() => setHi(i)}
                onMouseDown={(e) => {
                  e.preventDefault();
                  selectIdx(i);
                }}
                style={{
                  padding: "10px 12px",
                  fontSize: 14,
                  lineHeight: 1.35,
                  cursor: "pointer",
                  background: i === hi ? "#eef3ff" : "#fff",
                }}
              >
                {it.label}
              </div>
            ))}
        </div>
      )}
    </div>
  );
}

export default function Page() {
  const [startInput, setStartInput] = useState("6.9603, 50.9375");
  const [endInput, setEndInput] = useState("7.4653, 51.5136");
  const [startPick, setStartPick] = useState<Suggestion | null>(null);
  const [endPick, setEndPick] = useState<Suggestion | null>(null);

  const [width, setWidth] = useState(3);
  const [height, setHeight] = useState(4);
  const [weight, setWeight] = useState(40);
  const [axle, setAxle] = useState(10);
  const [buffer, setBuffer] = useState(40);

  const mapRef = useRef<Map | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [geojson, setGeojson] = useState<any | null>(null);
  const [activeIdx, setActiveIdx] = useState(0);
  const [steps, setSteps] = useState<
    { instruction: string; distance_km: number; duration_s: number; street_names: string[] }[]
  >([]);
  const [streets, setStreets] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const [startCoord, setStartCoord] = useState<Coords | null>(null);
  const [endCoord, setEndCoord] = useState<Coords | null>(null);

  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: {
        version: 8,
        sources: {
          osm: {
            type: "raster",
            tiles: [
              "https://a.tile.openstreetmap.org/{z}/{x}/{y}.png",
              "https://b.tile.openstreetmap.org/{z}/{x}/{y}.png",
              "https://c.tile.openstreetmap.org/{z}/{x}/{y}.png",
            ],
            tileSize: 256,
            attribution:
              '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
          },
          "route-active": { type: "geojson", data: { type: "FeatureCollection", features: [] } },
          "route-alts": { type: "geojson", data: { type: "FeatureCollection", features: [] } },
          points: { type: "geojson", data: { type: "FeatureCollection", features: [] } },
        },
        layers: [
          { id: "osm", type: "raster", source: "osm" },
          {
            id: "route-active-casing",
            type: "line",
            source: "route-active",
            paint: { "line-color": "#ffffff", "line-width": 9, "line-opacity": 0.9 },
            layout: { "line-join": "round", "line-cap": "round" },
          },
          {
            id: "route-active-line",
            type: "line",
            source: "route-active",
            paint: { "line-color": "#1E90FF", "line-width": 6 },
            layout: { "line-join": "round", "line-cap": "round" },
          },
          {
            id: "route-alts-line",
            type: "line",
            source: "route-alts",
            paint: { "line-color": "#666", "line-width": 5, "line-opacity": 0.9, "line-dasharray": [2, 2] },
            layout: { "line-join": "round", "line-cap": "round" },
          },
          {
            id: "points-circle",
            type: "circle",
            source: "points",
            paint: {
              "circle-radius": 6,
              "circle-color": ["match", ["get", "role"], "start", "#00A651", "#D84A4A"],
              "circle-stroke-color": "#fff",
              "circle-stroke-width": 2,
            },
          },
        ],
      },
      center: [7.1, 51.1],
      zoom: 8.2,
    });

    mapRef.current = map;

    map.on("mouseenter", "route-alts-line", () => (map.getCanvas().style.cursor = "pointer"));
    map.on("mouseleave", "route-alts-line", () => (map.getCanvas().style.cursor = ""));
    map.on("click", "route-alts-line", (e: MapMouseEvent) => {
      const idx = e.features?.[0]?.properties?.idx;
      if (typeof idx === "number") setActiveIdx(idx);
    });

    const onResize = () => map.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !geojson) return;

    const features: any[] = geojson.features ?? [];
    const active = features[activeIdx] ?? features[0];
    const alts = features
      .map((f: any, i: number) => ({ ...f, properties: { ...(f.properties || {}), idx: i } }))
      .filter((_: any, i: number) => i !== activeIdx);

    (map.getSource("route-active") as maplibregl.GeoJSONSource).setData({
      type: "FeatureCollection",
      features: active ? [active] : [],
    });
    (map.getSource("route-alts") as maplibregl.GeoJSONSource).setData({
      type: "FeatureCollection",
      features: alts,
    });

    const maneuvers = active?.properties?.maneuvers ?? [];
    setSteps(maneuvers);
    setStreets(active?.properties?.streets_sequence ?? []);

    const pts: any[] = [];
    if (startCoord)
      pts.push({ type: "Feature", geometry: { type: "Point", coordinates: startCoord }, properties: { role: "start" } });
    if (endCoord)
      pts.push({ type: "Feature", geometry: { type: "Point", coordinates: endCoord }, properties: { role: "end" } });
    (map.getSource("points") as maplibregl.GeoJSONSource).setData({
      type: "FeatureCollection",
      features: pts,
    });

    const bbox: [number, number, number, number] | undefined = active?.properties?.bbox;
    if (bbox) {
      map.fitBounds(
        [
          [bbox[0], bbox[1]],
          [bbox[2], bbox[3]],
        ],
        { padding: { top: 40, right: 40, bottom: 40, left: 340 } }
      );
    }
  }, [geojson, activeIdx, startCoord, endCoord]);

  async function planRoute() {
    setLoading(true);
    document.body.style.cursor = "progress";

    const toCoords = async (input: string, pick: Suggestion | null): Promise<Coords> => {
      if (pick && input.trim() === pick.label.trim()) return pick.coord;
      const ll = parseLonLat(input.trim());
      if (ll) return ll;
      const g = await geocode(input.trim());
      if (!g) throw new Error(`Konnte nicht geocodieren: "${input}"`);
      return g as Coords;
    };

    try {
      const start = await toCoords(startInput, startPick);
      const end = await toCoords(endInput, endPick);
      setStartCoord(start);
      setEndCoord(end);

      const res = await fetch("/api/route/valhalla", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          start,
          end,
          vehicle: { width_m: width, height_m: height, weight_t: weight, axleload_t: axle },
          buffer_m: buffer,
          directions_language: "de-DE",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert("Valhalla-Fehler: " + JSON.stringify(data?.error || data));
        return;
      }
      setGeojson(data.geojson);
      setActiveIdx(0);
      mapRef.current?.resize();
    } catch (e: any) {
      alert(String(e));
    } finally {
      setLoading(false);
      document.body.style.cursor = "auto";
    }
  }

  function exportTxt() {
    const f = geojson?.features?.[activeIdx];
    if (!f) return;
    const distKm = Number(f.properties?.summary?.distance_km ?? 0);
    const timeS = Number(f.properties?.summary?.duration_s ?? 0);
    const lines: string[] = [];
    lines.push("Route – Zusammenfassung");
    lines.push(`Distanz: ${distKm.toFixed(1)} km • Dauer: ${sToMin(timeS)} min`);
    lines.push("");
    lines.push("Anweisungen:");
    steps.forEach((s, i) =>
      lines.push(
        `${i + 1}. ${s.instruction}  (${s.distance_km.toFixed(1)} km, ${sToMin(
          s.duration_s
        )} min)`
      )
    );
    lines.push("");
    lines.push("Befahrene Straßen (chronologisch, nicht dedupliziert):");
    streets.forEach((name, i) => lines.push(`${i + 1}. ${name}`));
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "route.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  const getMapInfo = () => {
    const m = mapRef.current;
    if (!m) return {};
    const c = m.getCenter();
    const b = m.getBounds();
    return {
      center: { lat: c.lat, lon: c.lng },
      bounds: { left: b.getWest(), top: b.getNorth(), right: b.getEast(), bottom: b.getSouth() },
    };
  };

  useEffect(() => {
    setStartPick(null);
  }, [startInput]);
  useEffect(() => {
    setEndPick(null);
  }, [endInput]);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "340px 1fr", height: "100vh" }}>
      <div style={{ padding: 12, overflowY: "auto", borderRight: "1px solid #eee" }}>
        <h2 style={{ marginTop: 4 }}>Schwertransport – Routen-MVP</h2>
        <p style={{ margin: "8px 0 12px 0" }}>
          Adresse <b>oder</b> „lon, lat“ eingeben. Alternativrouten sind anklickbar.
        </p>

        <label>Start</label>
        <AutocompleteInput
          value={startInput}
          onChange={setStartInput}
          placeholder="Straße Hausnr, PLZ Ort"
          onSelect={(s) => {
            setStartInput(s.label);
            setStartPick(s);
          }}
          getMapInfo={getMapInfo}
        />

        <label>Ziel</label>
        <AutocompleteInput
          value={endInput}
          onChange={setEndInput}
          placeholder="Straße Hausnr, PLZ Ort"
          onSelect={(s) => {
            setEndInput(s.label);
            setEndPick(s);
          }}
          getMapInfo={getMapInfo}
        />

        <div className="row" style={{ marginTop: 6 }}>
          <div className="col">
            <label>Breite (m)</label>
            <input
              className="inp"
              type="number"
              value={width}
              onChange={(e) => setWidth(Number(e.target.value))}
            />
          </div>
          <div className="col">
            <label>Höhe (m)</label>
            <input
              className="inp"
              type="number"
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
            />
          </div>
        </div>

        <div className="row">
          <div className="col">
            <label>Gewicht (t)</label>
            <input
              className="inp"
              type="number"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
            />
          </div>
          <div className="col">
            <label>Achs-last (t)</label>
            <input
              className="inp"
              type="number"
              value={axle}
              onChange={(e) => setAxle(Number(e.target.value))}
            />
          </div>
        </div>

        <label>Buffer um Avoid-Punkt (m)</label>
        <input
          className="inp"
          type="number"
          value={buffer}
          onChange={(e) => setBuffer(Number(e.target.value))}
        />

        <button className={`primary ${loading ? "loading" : ""}`} onClick={planRoute} disabled={loading}>
          {loading ? "Plane…" : "Route planen"}
        </button>

        {steps.length > 0 && (
          <>
            <div className="legend" style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 12 }}>
              <span>
                <span className="dot blue" />
                Aktive Route
              </span>
              <span>
                <span className="dot gray" />
                Alternativen (anklickbar)
              </span>
            </div>

            <div className="directions" style={{ marginTop: 12 }}>
              <div className="head">
                <b>Anweisungen</b>
                <span className="spacer" />
                <button onClick={exportTxt}>Als TXT exportieren</button>
              </div>
              <ol>
                {steps.map((s, i) => (
                  <li key={i}>
                    <div>{s.instruction}</div>
                    <small>
                      {s.distance_km.toFixed(1)} km · {sToMin(s.duration_s)} min
                    </small>
                    {!!s.street_names?.length && (
                      <div className="muted">Straßen (Manöver): {s.street_names.join(", ")}</div>
                    )}
                  </li>
                ))}
              </ol>
            </div>

            <div className="directions" style={{ marginTop: 12 }}>
              <div className="head">
                <b>Befahrene Straßen (chronologisch, nicht dedupliziert)</b>
              </div>
              <ol>{streets.map((n, i) => <li key={i}><div>{n}</div></li>)}</ol>
            </div>
          </>
        )}
      </div>

      <div
        ref={containerRef}
        style={{ width: "100%", height: "100%", minHeight: "600px", background: "#f3f5f7" }}
      />
    </div>
  );
}
